package com.app.controller;

import com.app.dto.*;
import com.app.model.*;
import com.app.service.*;
import com.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.*;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin(origins = "*")
public class ChatController {

    @Autowired
    private ChatbotEngine chatbotEngine;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ChatSessionRepository chatSessionRepository;

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @PostMapping("/message")
    public ResponseEntity<ChatResponse> sendMessage(
            @Valid @RequestBody ChatRequest request,
            @RequestParam Long userId) {

        try {
            User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

            // Get or create chat session
            ChatSession session = getOrCreateSession(request.getSessionId(), user);

            // Save user message
            ChatMessage userMessage = new ChatMessage(session, request.getMessage(), true);
            userMessage.setMessageType(ChatMessage.MessageType.valueOf(request.getMessageType()));
            chatMessageRepository.save(userMessage);

            // Process message and get response
            ChatResponse response = chatbotEngine.processMessage(request, user);

            // Save bot response
            ChatMessage botMessage = new ChatMessage(session, response.getMessage(), false);
            botMessage.setConfidenceScore(response.getConfidenceScore());
            chatMessageRepository.save(botMessage);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            System.err.println("Error in ChatController.sendMessage: " + e.getMessage());
            e.printStackTrace();

            ChatResponse errorResponse = new ChatResponse(
                "I'm here to help with your career questions! Let me know what you'd like to explore - career paths, skills, job search tips, or any professional development topics."
            );
            errorResponse.setConfidenceScore(1.0f);
            return ResponseEntity.ok(errorResponse);
        }
    }

    @PostMapping("/session/start")
    public ResponseEntity<ChatSession> startSession(
            @RequestParam Long userId,
            @RequestParam(defaultValue = "CAREER_EXPLORATION") String sessionType) {

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));

        ChatSession session = new ChatSession(user, sessionType);
        session.setSessionTitle("Career Guidance Session - " + new Date());
        chatSessionRepository.save(session);

        // Send welcome message
        ChatMessage welcomeMessage = new ChatMessage(session,
            "Hello! I'm your AI career counselor. I'm here to help you explore career opportunities, " +
            "assess your skills, and plan your professional journey. How can I assist you today?",
            false);
        welcomeMessage.setMessageType(ChatMessage.MessageType.SYSTEM);
        chatMessageRepository.save(welcomeMessage);

        return ResponseEntity.ok(session);
    }

    @GetMapping("/session/{sessionId}/history")
    public ResponseEntity<List<ChatMessage>> getSessionHistory(@PathVariable Long sessionId) {
        List<ChatMessage> messages = chatMessageRepository.findByChatSessionIdOrderByCreatedAtAsc(sessionId);
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/user/{userId}/sessions")
    public ResponseEntity<List<ChatSession>> getUserSessions(@PathVariable Long userId) {
        List<ChatSession> sessions = chatSessionRepository.findByUserIdOrderByLastActivityDesc(userId);
        return ResponseEntity.ok(sessions);
    }

    @PostMapping("/voice")
    public ResponseEntity<ChatResponse> processVoiceMessage(
            @RequestParam("audio") String audioData,
            @RequestParam Long userId,
            @RequestParam(required = false) String sessionId) {

        try {
            // This would integrate with speech-to-text services
            String transcribedText = processAudioToText(audioData);

            ChatRequest request = new ChatRequest(transcribedText);
            request.setSessionId(sessionId);
            request.setMessageType("VOICE");
            request.setAudioData(audioData);

            return sendMessage(request, userId);

        } catch (Exception e) {
            ChatResponse errorResponse = new ChatResponse(
                "I couldn't process your voice message. Please try speaking again or type your message."
            );
            return ResponseEntity.ok(errorResponse);
        }
    }

    @PostMapping("/feedback")
    public ResponseEntity<String> provideFeedback(
            @RequestParam Long sessionId,
            @RequestParam int rating,
            @RequestParam(required = false) String comments) {

        // Store feedback for improving the chatbot
        // This would be saved to a feedback table

        return ResponseEntity.ok("Thank you for your feedback!");
    }

    private ChatSession getOrCreateSession(String sessionId, User user) {
        if (sessionId != null && !sessionId.isEmpty()) {
            // For string-based session IDs, we need to either:
            // 1. Find existing session by a custom identifier, or
            // 2. Create a new session and store the string ID reference

            // Check if it's a numeric session ID (existing database ID)
            try {
                Long numericSessionId = Long.parseLong(sessionId);
                return chatSessionRepository.findById(numericSessionId)
                    .orElseGet(() -> createNewSession(user, sessionId));
            } catch (NumberFormatException e) {
                // It's a string-based session ID, create new session
                return createNewSession(user, sessionId);
            }
        }

        // Create new session
        return createNewSession(user, null);
    }

    private ChatSession createNewSession(User user, String sessionIdentifier) {
        ChatSession session = new ChatSession(user, "GENERAL");
        session.setSessionTitle("Career Guidance Session - " + new Date());
        return chatSessionRepository.save(session);
    }

    private String processAudioToText(String audioData) {
        // This would integrate with Azure Speech Services or Google Speech-to-Text
        // For now, return a placeholder
        return "I heard your voice message";
    }
}

