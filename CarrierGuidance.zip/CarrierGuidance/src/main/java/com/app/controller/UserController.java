package com.app.controller;

import com.app.model.*;
import com.app.service.*;
import com.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import jakarta.servlet.http.HttpSession;
import java.util.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private TranslationService translationService;

    // Helper method to check authentication and get current user
    private User getCurrentUser(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return null;
        }
        return userRepository.findById(userId).orElse(null);
    }

    // Helper method to check if user is admin
    private boolean isAdmin(HttpSession session) {
        String userRole = (String) session.getAttribute("userRole");
        return "ADMIN".equals(userRole);
    }

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@Valid @RequestBody User user) {
        try {
            // Check if user already exists
            if (userRepository.findByEmail(user.getEmail()).isPresent()) {
                throw new RuntimeException("User with this email already exists");
            }

            User savedUser = userRepository.save(user);

            // Create default user profile
            UserProfile profile = new UserProfile(savedUser);
            userProfileRepository.save(profile);
            savedUser.setProfile(profile);

            return ResponseEntity.ok(savedUser);

        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<User> getUser(@PathVariable Long userId) {
        return userRepository.findById(userId)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{userId}")
    public ResponseEntity<User> updateUser(@PathVariable Long userId, @Valid @RequestBody User userUpdate) {
        return userRepository.findById(userId)
            .map(user -> {
                user.setFirstName(userUpdate.getFirstName());
                user.setLastName(userUpdate.getLastName());
                user.setAge(userUpdate.getAge());
                user.setEducation(userUpdate.getEducation());
                user.setCurrentJob(userUpdate.getCurrentJob());
                user.setLocation(userUpdate.getLocation());
                user.setPreferredLanguage(userUpdate.getPreferredLanguage());
                return ResponseEntity.ok(userRepository.save(user));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{userId}/profile")
    public ResponseEntity<UserProfile> getUserProfile(@PathVariable Long userId) {
        return userProfileRepository.findByUserId(userId)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{userId}/profile")
    public ResponseEntity<UserProfile> updateUserProfile(
            @PathVariable Long userId,
            @Valid @RequestBody UserProfile profileUpdate) {

        return userProfileRepository.findByUserId(userId)
            .map(profile -> {
                profile.setInterests(profileUpdate.getInterests());
                profile.setSkills(profileUpdate.getSkills());
                profile.setStrengths(profileUpdate.getStrengths());
                profile.setPreferredIndustry(profileUpdate.getPreferredIndustry());
                profile.setWorkEnvironment(profileUpdate.getWorkEnvironment());
                profile.setCareerStage(profileUpdate.getCareerStage());
                profile.setExpectedSalaryMin(profileUpdate.getExpectedSalaryMin());
                profile.setExpectedSalaryMax(profileUpdate.getExpectedSalaryMax());
                profile.setWorkLifeBalance(profileUpdate.getWorkLifeBalance());
                profile.setWillingToRelocate(profileUpdate.getWillingToRelocate());
                return ResponseEntity.ok(userProfileRepository.save(profile));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{userId}/assessment")
    public ResponseEntity<Map<String, Object>> conductAssessment(
            @PathVariable Long userId,
            @RequestBody Map<String, Object> assessmentData) {

        Optional<UserProfile> profileOpt = userProfileRepository.findByUserId(userId);
        if (profileOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserProfile profile = profileOpt.get();

        // Update assessment scores
        if (assessmentData.containsKey("personalityScore")) {
            profile.setPersonalityScore((Integer) assessmentData.get("personalityScore"));
        }
        if (assessmentData.containsKey("aptitudeScore")) {
            profile.setAptitudeScore((Integer) assessmentData.get("aptitudeScore"));
        }
        if (assessmentData.containsKey("experienceScore")) {
            profile.setExperienceScore((Integer) assessmentData.get("experienceScore"));
        }

        profile.setLastAssessmentDate(java.time.LocalDateTime.now());
        userProfileRepository.save(profile);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Assessment completed successfully");
        response.put("profile", profile);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/languages")
    public ResponseEntity<List<String>> getSupportedLanguages() {
        return ResponseEntity.ok(translationService.getSupportedLanguagesList());
    }

    @GetMapping("/profiles")
    public ResponseEntity<?> getAllProfiles(HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Authentication required"));
        }

        // Only admins can see all profiles
        if (!currentUser.isAdmin()) {
            return ResponseEntity.status(403).body(Map.of("error", "Access denied. Admin privileges required."));
        }

        List<UserProfile> profiles = userProfileRepository.findAll();
        return ResponseEntity.ok(profiles);
    }

    @GetMapping("/profile")
    public ResponseEntity<?> getCurrentUserProfile(HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Authentication required"));
        }

        // Users can only see their own profile
        Optional<UserProfile> profile = userProfileRepository.findByUserId(currentUser.getId());
        if (profile.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(profile.get());
    }

    @PostMapping("/profiles")
    public ResponseEntity<?> createProfile(@Valid @RequestBody Map<String, Object> profileData, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Authentication required"));
        }

        try {
            // Check if user already has a profile
            Optional<UserProfile> existingProfile = userProfileRepository.findByUserId(currentUser.getId());
            if (existingProfile.isPresent()) {
                return ResponseEntity.badRequest().body(Map.of("error", "User already has a profile. Use update instead."));
            }

            // Create profile for current user
            UserProfile profile = new UserProfile(currentUser);

            // Set profile data
            if (profileData.containsKey("interests")) {
                profile.setInterests((List<String>) profileData.get("interests"));
            }
            if (profileData.containsKey("skills")) {
                profile.setSkills((List<String>) profileData.get("skills"));
            }
            if (profileData.containsKey("strengths")) {
                profile.setStrengths((List<String>) profileData.get("strengths"));
            }
            if (profileData.containsKey("preferredIndustry")) {
                profile.setPreferredIndustry((String) profileData.get("preferredIndustry"));
            }
            if (profileData.containsKey("workEnvironment")) {
                profile.setWorkEnvironment((String) profileData.get("workEnvironment"));
            }
            if (profileData.containsKey("careerStage")) {
                profile.setCareerStage((String) profileData.get("careerStage"));
            }
            if (profileData.containsKey("expectedSalaryMin")) {
                profile.setExpectedSalaryMin((Integer) profileData.get("expectedSalaryMin"));
            }
            if (profileData.containsKey("expectedSalaryMax")) {
                profile.setExpectedSalaryMax((Integer) profileData.get("expectedSalaryMax"));
            }
            if (profileData.containsKey("workLifeBalance")) {
                profile.setWorkLifeBalance((String) profileData.get("workLifeBalance"));
            }
            if (profileData.containsKey("willingToRelocate")) {
                profile.setWillingToRelocate((Boolean) profileData.get("willingToRelocate"));
            }

            UserProfile savedProfile = userProfileRepository.save(profile);
            return ResponseEntity.ok(savedProfile);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to create profile"));
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateCurrentUserProfile(@Valid @RequestBody UserProfile profileUpdate, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Authentication required"));
        }

        return userProfileRepository.findByUserId(currentUser.getId())
            .map(profile -> {
                // Users can only update their own profile
                profile.setInterests(profileUpdate.getInterests());
                profile.setSkills(profileUpdate.getSkills());
                profile.setStrengths(profileUpdate.getStrengths());
                profile.setPreferredIndustry(profileUpdate.getPreferredIndustry());
                profile.setWorkEnvironment(profileUpdate.getWorkEnvironment());
                profile.setCareerStage(profileUpdate.getCareerStage());
                profile.setExpectedSalaryMin(profileUpdate.getExpectedSalaryMin());
                profile.setExpectedSalaryMax(profileUpdate.getExpectedSalaryMax());
                profile.setWorkLifeBalance(profileUpdate.getWorkLifeBalance());
                profile.setWillingToRelocate(profileUpdate.getWillingToRelocate());
                return ResponseEntity.ok(userProfileRepository.save(profile));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/profiles/{profileId}")
    public ResponseEntity<?> deleteProfile(@PathVariable Long profileId, HttpSession session) {
        User currentUser = getCurrentUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Authentication required"));
        }

        // Only admins can delete profiles
        if (!currentUser.isAdmin()) {
            return ResponseEntity.status(403).body(Map.of("error", "Access denied. Admin privileges required."));
        }

        if (userProfileRepository.existsById(profileId)) {
            userProfileRepository.deleteById(profileId);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}

