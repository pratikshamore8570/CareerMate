package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.app.service.CareerRecommendationService;
import com.app.service.ChatbotEngine;
import com.app.model.User;
import com.app.model.UserProfile;
import com.app.repository.UserRepository;
import com.app.dto.ChatRequest;
import com.app.dto.ChatResponse;
import com.app.dto.CareerRecommendation;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class WebController {

    @Autowired
    private CareerRecommendationService careerService;

    @Autowired
    private ChatbotEngine chatbotEngine;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/chat")
    public String chat(Model model) {
        model.addAttribute("chatRequest", new ChatRequest());
        return "chat";
    }

    @GetMapping("/profile")
    public String profile(Model model) {
        model.addAttribute("user", new User());
        return "profile";
    }

    @GetMapping("/profiles")
    public String allProfiles(Model model) {
        return "profiles";
    }

    @GetMapping("/profiles/create")
    public String createProfile(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("userProfile", new UserProfile());
        return "create-profile";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @GetMapping("/recommendations")
    public String recommendations(Model model, HttpServletRequest request) {
        try {
            // Get user ID from session (you should implement proper session management)
            Long userId = getUserIdFromSession(request);

            if (userId != null) {
                // Get personalized recommendations for logged-in user
                List<CareerRecommendation> recommendations = careerService.getPersonalizedRecommendations(userId);
                model.addAttribute("recommendations", recommendations);
                model.addAttribute("isPersonalized", true);

                // Get user info for display
                User user = userRepository.findById(userId).orElse(null);
                if (user != null) {
                    model.addAttribute("userName", user.getFirstName() + " " + user.getLastName());
                    model.addAttribute("hasProfile", user.getProfile() != null);
                }
            } else {
                // Show default recommendations for non-logged-in users
                List<CareerRecommendation> recommendations = careerService.getDefaultRecommendations();
                model.addAttribute("recommendations", recommendations);
                model.addAttribute("isPersonalized", false);
                model.addAttribute("message", "Log in to get personalized recommendations based on your profile");
            }
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load recommendations: " + e.getMessage());
            model.addAttribute("recommendations", careerService.getDefaultRecommendations());
        }
        return "recommendations";
    }

    // Helper method to get user ID from session
    private Long getUserIdFromSession(HttpServletRequest request) {
        // This is a simplified approach - implement proper session management
        // For demo purposes, you can hardcode a user ID or get from session
        HttpSession session = request.getSession(false);
        if (session != null) {
            Object userId = session.getAttribute("userId");
            if (userId != null) {
                return Long.valueOf(userId.toString());
            }
        }

        // For demo, try to get the first user from database
        List<User> users = userRepository.findAll();
        return users.isEmpty() ? null : users.get(0).getId();
    }

    // Add new endpoint for refreshing recommendations
    @GetMapping("/recommendations/refresh")
    public String refreshRecommendations(Model model, HttpServletRequest request) {
        return recommendations(model, request);
    }

    // Add endpoint to get recommendations by industry filter
    @GetMapping("/recommendations/industry/{industry}")
    public String recommendationsByIndustry(@PathVariable String industry, Model model, HttpServletRequest request) {
        try {
            Long userId = getUserIdFromSession(request);

            if (userId != null) {
                User user = userRepository.findById(userId).orElse(null);
                if (user != null && user.getProfile() != null) {
                    // Get all recommendations and filter by industry
                    List<CareerRecommendation> allRecommendations = careerService.getPersonalizedRecommendations(userId);
                    List<CareerRecommendation> filteredRecommendations = allRecommendations.stream()
                        .filter(rec -> rec.getIndustry().equalsIgnoreCase(industry))
                        .collect(Collectors.toList());

                    model.addAttribute("recommendations", filteredRecommendations);
                    model.addAttribute("selectedIndustry", industry);
                    model.addAttribute("isPersonalized", true);
                }
            }
        } catch (Exception e) {
            model.addAttribute("error", "Unable to filter recommendations: " + e.getMessage());
        }

        return "recommendations";
    }

    @PostMapping("/api/chat")
    @ResponseBody
    public ChatResponse chatApi(@RequestBody ChatRequest request) {
        try {
            // Create a mock user for chat processing
            User mockUser = new User();
            mockUser.setId(1L);
            return chatbotEngine.processMessage(request, mockUser);
        } catch (Exception e) {
            ChatResponse errorResponse = new ChatResponse();
            errorResponse.setMessage("Sorry, I encountered an error processing your message: " + e.getMessage());
            return errorResponse;
        }
    }
}
