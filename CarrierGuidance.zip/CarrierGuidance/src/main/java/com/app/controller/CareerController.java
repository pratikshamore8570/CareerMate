package com.app.controller;

import com.app.dto.*;
import com.app.model.*;
import com.app.service.*;
import com.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/careers")
@CrossOrigin(origins = "*")
public class CareerController {

    @Autowired
    private CareerRecommendationService careerService;

    @Autowired
    private CareerPathRepository careerPathRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/recommendations/{userId}")
    public ResponseEntity<List<CareerRecommendation>> getCareerRecommendations(
            @PathVariable Long userId,
            @RequestParam(required = false) List<String> interests) {

        try {
            List<CareerRecommendation> recommendations = careerService.getPersonalizedRecommendations(userId);
            return ResponseEntity.ok(recommendations);
        } catch (Exception e) {
            // Fallback to basic recommendations if user not found
            User mockUser = new User();
            mockUser.setId(userId);
            List<CareerRecommendation> fallbackRecommendations = careerService.getCareerRecommendations(mockUser, interests);
            return ResponseEntity.ok(fallbackRecommendations);
        }
    }

    // New endpoint for getting recommendations with detailed profile analysis
    @GetMapping("/recommendations/detailed/{userId}")
    public ResponseEntity<Map<String, Object>> getDetailedRecommendations(@PathVariable Long userId) {
        try {
            User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

            List<CareerRecommendation> recommendations = careerService.getPersonalizedRecommendations(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("recommendations", recommendations);
            response.put("profileCompleteness", calculateProfileCompleteness(user.getProfile()));
            response.put("recommendationCount", recommendations.size());
            response.put("isPersonalized", user.getProfile() != null);

            if (user.getProfile() != null) {
                response.put("topInterests", user.getProfile().getInterests());
                response.put("topSkills", user.getProfile().getSkills());
                response.put("preferredIndustry", user.getProfile().getPreferredIndustry());
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            errorResponse.put("recommendations", careerService.getDefaultRecommendations());
            return ResponseEntity.ok(errorResponse);
        }
    }

    // Helper method to calculate profile completeness
    private int calculateProfileCompleteness(UserProfile profile) {
        if (profile == null) return 0;

        int totalFields = 8;
        int completedFields = 0;

        if (profile.getInterests() != null && !profile.getInterests().isEmpty()) completedFields++;
        if (profile.getSkills() != null && !profile.getSkills().isEmpty()) completedFields++;
        if (profile.getPreferredIndustry() != null) completedFields++;
        if (profile.getCareerStage() != null) completedFields++;
        if (profile.getExpectedSalaryMin() != null) completedFields++;
        if (profile.getWorkEnvironment() != null) completedFields++;
        if (profile.getWorkLifeBalance() != null) completedFields++;
        if (profile.getWillingToRelocate() != null) completedFields++;

        return (completedFields * 100) / totalFields;
    }

    @GetMapping("/paths")
    public ResponseEntity<List<CareerPath>> getAllCareerPaths(
            @RequestParam(required = false) String industry,
            @RequestParam(required = false) String jobOutlook) {

        List<CareerPath> careers;

        if (industry != null) {
            careers = careerPathRepository.findByIndustry(industry);
        } else if (jobOutlook != null) {
            careers = careerPathRepository.findByJobOutlook(jobOutlook);
        } else {
            careers = careerPathRepository.findAll();
        }

        return ResponseEntity.ok(careers);
    }

    @GetMapping("/paths/{pathId}")
    public ResponseEntity<CareerPath> getCareerPath(@PathVariable Long pathId) {
        return careerPathRepository.findById(pathId)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public ResponseEntity<List<CareerPath>> searchCareers(
            @RequestParam String query,
            @RequestParam(required = false) Integer minSalary,
            @RequestParam(required = false) Integer maxSalary) {

        List<CareerPath> results;

        if (minSalary != null && maxSalary != null) {
            results = careerPathRepository.findBySalaryRange(minSalary, maxSalary);
        } else {
            results = careerPathRepository.findByTitleContaining(query);
        }

        return ResponseEntity.ok(results);
    }

    @GetMapping("/salary-info")
    public ResponseEntity<Map<String, Object>> getSalaryInformation(
            @RequestParam String jobTitle,
            @RequestParam String location) {

        Map<String, Object> salaryInfo = careerService.getSalaryInformation(jobTitle, location);
        return ResponseEntity.ok(salaryInfo);
    }

    @PostMapping("/skills-assessment")
    public ResponseEntity<Map<String, Integer>> assessSkills(
            @RequestBody List<String> skills,
            @RequestParam Long userId) {

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));

        Map<String, Integer> assessment = careerService.assessSkills(skills, user);
        return ResponseEntity.ok(assessment);
    }

    @GetMapping("/industries")
    public ResponseEntity<List<String>> getIndustries() {
        List<String> industries = Arrays.asList(
            "Technology", "Healthcare", "Finance", "Education", "Engineering",
            "Marketing", "Sales", "Design", "Manufacturing", "Consulting",
            "Non-Profit", "Government", "Entertainment", "Agriculture", "Energy"
        );
        return ResponseEntity.ok(industries);
    }

    @GetMapping("/trending")
    public ResponseEntity<List<CareerPath>> getTrendingCareers() {
        // Get careers with good job outlook
        List<CareerPath> trending = careerPathRepository.findByJobOutlook("EXCELLENT");
        return ResponseEntity.ok(trending.stream().limit(10).collect(Collectors.toList()));
    }
}


