package com.app.repository;

import com.app.model.CareerPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CareerPathRepository extends JpaRepository<CareerPath, Long> {
    List<CareerPath> findByIndustry(String industry);
    List<CareerPath> findByJobOutlook(String jobOutlook);

    @Query("SELECT c FROM CareerPath c WHERE c.averageSalaryMin <= ?1 AND c.averageSalaryMax >= ?2")
    List<CareerPath> findBySalaryRange(Integer minSalary, Integer maxSalary);

    @Query("SELECT c FROM CareerPath c WHERE LOWER(c.title) LIKE LOWER(CONCAT('%', ?1, '%'))")
    List<CareerPath> findByTitleContaining(String title);

    @Query("SELECT c FROM CareerPath c JOIN c.requiredSkills s WHERE s IN ?1")
    List<CareerPath> findByRequiredSkillsIn(List<String> skills);
}

