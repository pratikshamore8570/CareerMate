package com.app.repository;

import com.app.model.ChatSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ChatSessionRepository extends JpaRepository<ChatSession, Long> {
    List<ChatSession> findByUserIdAndIsActive(Long userId, boolean isActive);
    List<ChatSession> findByUserIdOrderByLastActivityDesc(Long userId);
    List<ChatSession> findBySessionType(String sessionType);

    @Query("SELECT cs FROM ChatSession cs WHERE cs.user.id = ?1 AND cs.lastActivity >= ?2")
    List<ChatSession> findRecentSessionsByUser(Long userId, LocalDateTime since);
}

