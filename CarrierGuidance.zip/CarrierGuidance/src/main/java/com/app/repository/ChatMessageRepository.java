package com.app.repository;

import com.app.model.ChatMessage;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    List<ChatMessage> findByChatSessionIdOrderByCreatedAtAsc(Long sessionId);
    List<ChatMessage> findByIsFromUserAndMessageType(boolean isFromUser, ChatMessage.MessageType messageType);

    @Query("SELECT cm FROM ChatMessage cm WHERE cm.chatSession.user.id = ?1 ORDER BY cm.createdAt DESC")
    List<ChatMessage> findLatestMessagesByUser(Long userId, Pageable pageable);
}