package com.app.model;

import jakarta.persistence.*;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "career_paths")
public class CareerPath {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String industry;
    private String description;
    private String educationRequired;
    private Integer averageSalaryMin;
    private Integer averageSalaryMax;
    private String jobOutlook; // EXCELLENT, GOOD, AVERAGE, POOR
    private String workEnvironment;

    @ElementCollection
    @CollectionTable(name = "career_required_skills")
    private List<String> requiredSkills = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "career_preferred_skills")
    private List<String> preferredSkills = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "career_progression_steps")
    private List<String> careerProgression = new ArrayList<>();

    private String onetCode; // O*NET occupation code for integration
    private Float matchingScore; // For ML-based matching

    // Constructors
    public CareerPath() {}

    public CareerPath(String title, String industry) {
        this.title = title;
        this.industry = industry;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getIndustry() { return industry; }
    public void setIndustry(String industry) { this.industry = industry; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getEducationRequired() { return educationRequired; }
    public void setEducationRequired(String educationRequired) { this.educationRequired = educationRequired; }

    public Integer getAverageSalaryMin() { return averageSalaryMin; }
    public void setAverageSalaryMin(Integer averageSalaryMin) { this.averageSalaryMin = averageSalaryMin; }

    public Integer getAverageSalaryMax() { return averageSalaryMax; }
    public void setAverageSalaryMax(Integer averageSalaryMax) { this.averageSalaryMax = averageSalaryMax; }

    public String getJobOutlook() { return jobOutlook; }
    public void setJobOutlook(String jobOutlook) { this.jobOutlook = jobOutlook; }

    public String getWorkEnvironment() { return workEnvironment; }
    public void setWorkEnvironment(String workEnvironment) { this.workEnvironment = workEnvironment; }

    public List<String> getRequiredSkills() { return requiredSkills; }
    public void setRequiredSkills(List<String> requiredSkills) { this.requiredSkills = requiredSkills; }

    public List<String> getPreferredSkills() { return preferredSkills; }
    public void setPreferredSkills(List<String> preferredSkills) { this.preferredSkills = preferredSkills; }

    public List<String> getCareerProgression() { return careerProgression; }
    public void setCareerProgression(List<String> careerProgression) { this.careerProgression = careerProgression; }

    public String getOnetCode() { return onetCode; }
    public void setOnetCode(String onetCode) { this.onetCode = onetCode; }

    public Float getMatchingScore() { return matchingScore; }
    public void setMatchingScore(Float matchingScore) { this.matchingScore = matchingScore; }
}
