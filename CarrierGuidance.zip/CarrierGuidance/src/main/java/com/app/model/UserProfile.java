package com.app.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "user_profiles")
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    // Career Interests
    @ElementCollection
    @CollectionTable(name = "user_interests")
    private List<String> interests = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "user_skills")
    private List<String> skills = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "user_strengths")
    private List<String> strengths = new ArrayList<>();

    // Career Preferences
    private String preferredIndustry;
    private String workEnvironment; // REMOTE, OFFICE, HYBRID
    private String careerStage; // ENTRY_LEVEL, MID_LEVEL, SENIOR_LEVEL
    private Integer expectedSalaryMin;
    private Integer expectedSalaryMax;
    private String workLifeBalance; // HIGH, MEDIUM, LOW
    private Boolean willingToRelocate;

    // Assessment Scores
    private Integer personalityScore;
    private Integer aptitudeScore;
    private Integer experienceScore;

    @Column(name = "last_assessment_date")
    private LocalDateTime lastAssessmentDate;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public UserProfile() {}

    public UserProfile(User user) {
        this.user = user;
        this.updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public List<String> getInterests() { return interests; }
    public void setInterests(List<String> interests) { this.interests = interests; }

    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }

    public List<String> getStrengths() { return strengths; }
    public void setStrengths(List<String> strengths) { this.strengths = strengths; }

    public String getPreferredIndustry() { return preferredIndustry; }
    public void setPreferredIndustry(String preferredIndustry) { this.preferredIndustry = preferredIndustry; }

    public String getWorkEnvironment() { return workEnvironment; }
    public void setWorkEnvironment(String workEnvironment) { this.workEnvironment = workEnvironment; }

    public String getCareerStage() { return careerStage; }
    public void setCareerStage(String careerStage) { this.careerStage = careerStage; }

    public Integer getExpectedSalaryMin() { return expectedSalaryMin; }
    public void setExpectedSalaryMin(Integer expectedSalaryMin) { this.expectedSalaryMin = expectedSalaryMin; }

    public Integer getExpectedSalaryMax() { return expectedSalaryMax; }
    public void setExpectedSalaryMax(Integer expectedSalaryMax) { this.expectedSalaryMax = expectedSalaryMax; }

    public String getWorkLifeBalance() { return workLifeBalance; }
    public void setWorkLifeBalance(String workLifeBalance) { this.workLifeBalance = workLifeBalance; }

    public Boolean getWillingToRelocate() { return willingToRelocate; }
    public void setWillingToRelocate(Boolean willingToRelocate) { this.willingToRelocate = willingToRelocate; }

    public Integer getPersonalityScore() { return personalityScore; }
    public void setPersonalityScore(Integer personalityScore) { this.personalityScore = personalityScore; }

    public Integer getAptitudeScore() { return aptitudeScore; }
    public void setAptitudeScore(Integer aptitudeScore) { this.aptitudeScore = aptitudeScore; }

    public Integer getExperienceScore() { return experienceScore; }
    public void setExperienceScore(Integer experienceScore) { this.experienceScore = experienceScore; }

    public LocalDateTime getLastAssessmentDate() { return lastAssessmentDate; }
    public void setLastAssessmentDate(LocalDateTime lastAssessmentDate) { this.lastAssessmentDate = lastAssessmentDate; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}