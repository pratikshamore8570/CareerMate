package com.app.dto;

import java.util.List;

public class ChatResponse {
    private String message;
    private String messageType;
    private List<CareerRecommendation> careerSuggestions;
    private List<String> followUpQuestions;
    private Float confidenceScore;
    private String language;
    private String audioUrl;
    private String sessionId;

    // Constructors
    public ChatResponse() {}

    public ChatResponse(String message) {
        this.message = message;
        this.messageType = "TEXT";
    }

    // Getters and Setters
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getMessageType() { return messageType; }
    public void setMessageType(String messageType) { this.messageType = messageType; }

    public List<CareerRecommendation> getCareerSuggestions() { return careerSuggestions; }
    public void setCareerSuggestions(List<CareerRecommendation> careerSuggestions) { this.careerSuggestions = careerSuggestions; }

    public List<String> getFollowUpQuestions() { return followUpQuestions; }
    public void setFollowUpQuestions(List<String> followUpQuestions) { this.followUpQuestions = followUpQuestions; }

    public Float getConfidenceScore() { return confidenceScore; }
    public void setConfidenceScore(Float confidenceScore) { this.confidenceScore = confidenceScore; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getAudioUrl() { return audioUrl; }
    public void setAudioUrl(String audioUrl) { this.audioUrl = audioUrl; }

    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
}


