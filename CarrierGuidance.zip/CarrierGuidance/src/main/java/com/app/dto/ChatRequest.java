package com.app.dto;

public class ChatRequest {
    private String sessionId;  // Changed from Long to String to handle web session IDs
    private String message;
    private String messageType; // TEXT, VOICE
    private String language;
    private String audioData; // Base64 encoded audio for voice messages

    // Constructors
    public ChatRequest() {}

    public ChatRequest(String message) {
        this.message = message;
        this.messageType = "TEXT";
    }

    // Getters and Setters
    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getMessageType() { return messageType; }
    public void setMessageType(String messageType) { this.messageType = messageType; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getAudioData() { return audioData; }
    public void setAudioData(String audioData) { this.audioData = audioData; }
}
