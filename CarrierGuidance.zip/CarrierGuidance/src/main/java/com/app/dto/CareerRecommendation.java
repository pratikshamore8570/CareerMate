package com.app.dto;

import java.util.List;

public class CareerRecommendation {
    private String title;
    private String careerTitle; // Alternative getter name
    private String industry;
    private Float matchScore;
    private String description;
    private Integer salaryRange;
    private String reasoning;
    private List<String> requiredSkills;
    private String growthPotential;

    // Constructors
    public CareerRecommendation() {}

    public CareerRecommendation(String title, String industry, Float matchScore) {
        this.title = title;
        this.careerTitle = title; // Set both for compatibility
        this.industry = industry;
        this.matchScore = matchScore;
    }

    public CareerRecommendation(String title, String industry, Float matchScore, String description,
                              Integer salaryRange, String reasoning, List<String> requiredSkills, String growthPotential) {
        this.title = title;
        this.careerTitle = title;
        this.industry = industry;
        this.matchScore = matchScore;
        this.description = description;
        this.salaryRange = salaryRange;
        this.reasoning = reasoning;
        this.requiredSkills = requiredSkills;
        this.growthPotential = growthPotential;
    }

    // Getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
        this.careerTitle = title; // Keep both in sync
    }

    public String getCareerTitle() {
        return careerTitle;
    }

    public void setCareerTitle(String careerTitle) {
        this.careerTitle = careerTitle;
        this.title = careerTitle; // Keep both in sync
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public Float getMatchScore() {
        return matchScore;
    }

    public void setMatchScore(Float matchScore) {
        this.matchScore = matchScore;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getSalaryRange() {
        return salaryRange;
    }

    public void setSalaryRange(Integer salaryRange) {
        this.salaryRange = salaryRange;
    }

    public String getReasoning() {
        return reasoning;
    }

    public void setReasoning(String reasoning) {
        this.reasoning = reasoning;
    }

    public List<String> getRequiredSkills() {
        return requiredSkills;
    }

    public void setRequiredSkills(List<String> requiredSkills) {
        this.requiredSkills = requiredSkills;
    }

    public String getGrowthPotential() {
        return growthPotential;
    }

    public void setGrowthPotential(String growthPotential) {
        this.growthPotential = growthPotential;
    }

    @Override
    public String toString() {
        return "CareerRecommendation{" +
                "title='" + title + '\'' +
                ", industry='" + industry + '\'' +
                ", matchScore=" + matchScore +
                ", description='" + description + '\'' +
                ", salaryRange=" + salaryRange +
                ", reasoning='" + reasoning + '\'' +
                ", requiredSkills=" + requiredSkills +
                ", growthPotential='" + growthPotential + '\'' +
                '}';
    }
}


