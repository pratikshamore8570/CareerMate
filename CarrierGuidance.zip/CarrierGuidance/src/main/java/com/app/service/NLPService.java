package com.app.service;

import org.springframework.stereotype.Service;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

@Service
public class NLPService {

    private final Map<String, List<String>> skillKeywords = initializeSkillKeywords();
    private final Map<String, List<String>> interestKeywords = initializeInterestKeywords();
    private final List<String> jobTitlePatterns = initializeJobTitlePatterns();

    public List<String> extractInterests(String message) {
        List<String> extractedInterests = new ArrayList<>();
        String lowerMessage = message.toLowerCase();

        for (Map.Entry<String, List<String>> entry : interestKeywords.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (lowerMessage.contains(keyword.toLowerCase())) {
                    extractedInterests.add(entry.getKey());
                    break;
                }
            }
        }

        return extractedInterests;
    }

    public List<String> extractSkills(String message) {
        List<String> extractedSkills = new ArrayList<>();
        String lowerMessage = message.toLowerCase();

        for (Map.Entry<String, List<String>> entry : skillKeywords.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (lowerMessage.contains(keyword.toLowerCase())) {
                    extractedSkills.add(entry.getKey());
                    break;
                }
            }
        }

        return extractedSkills;
    }

    public String extractJobTitle(String message) {
        for (String pattern : jobTitlePatterns) {
            Pattern p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(message);
            if (m.find()) {
                return m.group(1).trim();
            }
        }
        return "Software Developer"; // Default fallback
    }

    public String analyzeSentiment(String message) {
        // Simple sentiment analysis - in production, use advanced NLP libraries
        String lowerMessage = message.toLowerCase();

        List<String> positiveWords = Arrays.asList("excited", "interested", "love", "enjoy", "passionate", "great");
        List<String> negativeWords = Arrays.asList("hate", "dislike", "boring", "difficult", "stressed", "worried");

        long positiveCount = positiveWords.stream().mapToLong(word ->
            lowerMessage.contains(word) ? 1 : 0).sum();
        long negativeCount = negativeWords.stream().mapToLong(word ->
            lowerMessage.contains(word) ? 1 : 0).sum();

        if (positiveCount > negativeCount) return "POSITIVE";
        if (negativeCount > positiveCount) return "NEGATIVE";
        return "NEUTRAL";
    }

    public Map<String, Object> extractPersonalityTraits(String message) {
        Map<String, Object> traits = new HashMap<>();
        String lowerMessage = message.toLowerCase();

        // Extroversion indicators
        boolean isExtroverted = lowerMessage.contains("people") ||
                               lowerMessage.contains("team") ||
                               lowerMessage.contains("social");
        traits.put("extroversion", isExtroverted ? 0.7 : 0.3);

        // Analytical thinking
        boolean isAnalytical = lowerMessage.contains("data") ||
                              lowerMessage.contains("analyze") ||
                              lowerMessage.contains("problem");
        traits.put("analytical", isAnalytical ? 0.8 : 0.4);

        // Creative thinking
        boolean isCreative = lowerMessage.contains("creative") ||
                            lowerMessage.contains("design") ||
                            lowerMessage.contains("art");
        traits.put("creativity", isCreative ? 0.8 : 0.4);

        return traits;
    }

    private Map<String, List<String>> initializeSkillKeywords() {
        Map<String, List<String>> skills = new HashMap<>();

        skills.put("Programming", Arrays.asList("code", "programming", "java", "python", "javascript", "software"));
        skills.put("Data Analysis", Arrays.asList("data", "analytics", "statistics", "excel", "sql"));
        skills.put("Communication", Arrays.asList("communication", "presentation", "writing", "speaking"));
        skills.put("Leadership", Arrays.asList("leadership", "management", "team lead", "supervise"));
        skills.put("Design", Arrays.asList("design", "creative", "photoshop", "ui", "ux"));
        skills.put("Marketing", Arrays.asList("marketing", "advertising", "social media", "campaigns"));
        skills.put("Finance", Arrays.asList("finance", "accounting", "budgeting", "financial"));
        skills.put("Sales", Arrays.asList("sales", "selling", "customer", "negotiation"));

        return skills;
    }

    private Map<String, List<String>> initializeInterestKeywords() {
        Map<String, List<String>> interests = new HashMap<>();

        interests.put("Technology", Arrays.asList("technology", "computers", "software", "ai", "tech"));
        interests.put("Healthcare", Arrays.asList("healthcare", "medical", "nursing", "doctor", "health"));
        interests.put("Education", Arrays.asList("teaching", "education", "training", "school"));
        interests.put("Business", Arrays.asList("business", "entrepreneurship", "startup", "corporate"));
        interests.put("Arts", Arrays.asList("art", "creative", "music", "painting", "design"));
        interests.put("Science", Arrays.asList("science", "research", "laboratory", "biology", "chemistry"));
        interests.put("Engineering", Arrays.asList("engineering", "building", "construction", "mechanical"));
        interests.put("Finance", Arrays.asList("finance", "banking", "investment", "money"));

        return interests;
    }

    private List<String> initializeJobTitlePatterns() {
        return Arrays.asList(
            "\\b(\\w+\\s+\\w+)\\s+position",
            "\\b(\\w+\\s+\\w+)\\s+role",
            "\\b(\\w+\\s+\\w+)\\s+job",
            "as\\s+a\\s+(\\w+\\s+\\w+)",
            "become\\s+a\\s+(\\w+\\s+\\w+)"
        );
    }
}
