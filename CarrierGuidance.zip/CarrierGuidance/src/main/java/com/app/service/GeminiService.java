package com.app.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GeminiService {

    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    // You can get a free API key from https://makersuite.google.com/app/apikey
    @Value("${gemini.api.key:AIzaSyA7zSm6aREW2uojdzdiEA3F_XFoB5zDROg}")
    private String apiKey;

    // Updated API URL with current model name
    private static final String GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

    public GeminiService() {
        this.webClient = WebClient.builder().build();
        this.objectMapper = new ObjectMapper();
    }

    public String getCareerGuidanceResponse(String userMessage) {
        try {
            // Create the career guidance context prompt
            String contextPrompt = "You are an expert career guidance counselor and AI assistant. " +
                "Provide helpful, professional, and encouraging career advice. " +
                "Focus on career paths, skill development, job search strategies, education planning, and professional growth. " +
                "Keep responses concise but informative. " +
                "User question: " + userMessage;

            // If API key is not configured, provide a mock response
            if (apiKey == null || apiKey.equals("YOUR_API_KEY_HERE") || apiKey.trim().isEmpty()) {
                System.out.println("Using mock response - Gemini API key not configured properly");
                return getMockCareerResponse(userMessage);
            }

            // Create request payload for Gemini API
            Map<String, Object> requestBody = createGeminiRequest(contextPrompt);

            // Make API call to Gemini
            Mono<String> responseMono = webClient.post()
                .uri(GEMINI_API_URL + "?key=" + apiKey)
                .header("Content-Type", "application/json")
                .body(BodyInserters.fromValue(requestBody))
                .retrieve()
                .bodyToMono(String.class);

            // Get response and parse it
            String response = responseMono.block();
            String parsedResponse = parseGeminiResponse(response);

            if (parsedResponse != null && !parsedResponse.trim().isEmpty()) {
                return parsedResponse;
            } else {
                System.out.println("Gemini API returned empty response, using mock response");
                return getMockCareerResponse(userMessage);
            }

        } catch (Exception e) {
            System.err.println("Error calling Gemini API: " + e.getMessage());
            e.printStackTrace();
            return getMockCareerResponse(userMessage);
        }
    }

    private Map<String, Object> createGeminiRequest(String prompt) {
        Map<String, Object> request = new HashMap<>();
        Map<String, Object> content = new HashMap<>();
        Map<String, Object> part = new HashMap<>();

        part.put("text", prompt);
        content.put("parts", List.of(part));
        request.put("contents", List.of(content));

        return request;
    }

    private String parseGeminiResponse(String jsonResponse) {
        try {
            JsonNode root = objectMapper.readTree(jsonResponse);
            JsonNode candidates = root.get("candidates");
            if (candidates != null && candidates.isArray() && candidates.size() > 0) {
                JsonNode firstCandidate = candidates.get(0);
                JsonNode content = firstCandidate.get("content");
                if (content != null) {
                    JsonNode parts = content.get("parts");
                    if (parts != null && parts.isArray() && parts.size() > 0) {
                        JsonNode firstPart = parts.get(0);
                        JsonNode text = firstPart.get("text");
                        if (text != null) {
                            return text.asText();
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error parsing Gemini response: " + e.getMessage());
        }
        return "I'm here to help with your career questions! Could you please rephrase your question?";
    }

    private String getMockCareerResponse(String userMessage) {
        String lowerMessage = userMessage.toLowerCase();

        if (lowerMessage.contains("hello") || lowerMessage.contains("hi") || lowerMessage.contains("hey")) {
            return "Hello! I'm your AI career counselor. I'm here to help you navigate your professional journey. " +
                   "I can assist with career exploration, skill development, job search strategies, salary insights, and education planning. " +
                   "What career questions can I help you with today?";
        }

        if (lowerMessage.contains("career") || lowerMessage.contains("job")) {
            return "Great question about careers! Here are some popular career paths to consider:\n\n" +
                   "🚀 **Technology**: Software Developer, Data Scientist, Cybersecurity Analyst, AI Engineer\n" +
                   "💼 **Business**: Product Manager, Business Analyst, Marketing Specialist, Project Manager\n" +
                   "🏥 **Healthcare**: Nurse, Physical Therapist, Healthcare Administrator, Medical Technologist\n" +
                   "🎨 **Creative**: UX Designer, Content Creator, Graphic Designer, Digital Marketing\n\n" +
                   "What field interests you most? I can provide more specific guidance!";
        }

        if (lowerMessage.contains("skill") || lowerMessage.contains("learn")) {
            return "Skill development is crucial for career growth! Here are some high-demand skills:\n\n" +
                   "💻 **Technical Skills**: Programming (Python, Java, JavaScript), Data Analysis, Cloud Computing\n" +
                   "🧠 **Soft Skills**: Communication, Leadership, Problem-solving, Critical Thinking\n" +
                   "📊 **Business Skills**: Project Management, Digital Marketing, Financial Analysis\n\n" +
                   "Which skills would you like to develop? I can suggest learning resources and career paths!";
        }

        if (lowerMessage.contains("salary") || lowerMessage.contains("pay")) {
            return "Salary expectations vary by role, location, and experience. Here are some general ranges:\n\n" +
                   "💰 **Entry Level (0-2 years)**: $40,000 - $70,000\n" +
                   "💰 **Mid Level (3-5 years)**: $60,000 - $100,000\n" +
                   "💰 **Senior Level (6+ years)**: $80,000 - $150,000+\n\n" +
                   "Factors affecting salary: Location, industry, skills, education, and company size. " +
                   "What specific role are you interested in? I can provide more targeted information!";
        }

        if (lowerMessage.contains("programming") || lowerMessage.contains("developer") || lowerMessage.contains("software")) {
            return "Software development is an excellent career choice! Here's what you need to know:\n\n" +
                   "🔧 **Key Skills**: Programming languages (Python, Java, JavaScript), Problem-solving, Version control (Git)\n" +
                   "💼 **Career Paths**: Frontend Developer, Backend Developer, Full-Stack Developer, Mobile Developer\n" +
                   "📈 **Growth**: High demand, excellent salary potential, remote work opportunities\n" +
                   "🎓 **Getting Started**: Online courses, coding bootcamps, computer science degree, personal projects\n\n" +
                   "Would you like specific learning resources or information about a particular programming specialization?";
        }

        if (lowerMessage.contains("data") && lowerMessage.contains("science")) {
            return "Data Science is one of the hottest career fields! Here's your roadmap:\n\n" +
                   "🧮 **Core Skills**: Python/R, Statistics, Machine Learning, SQL, Data Visualization\n" +
                   "🏢 **Roles**: Data Scientist, Data Analyst, ML Engineer, Business Intelligence Analyst\n" +
                   "💰 **Salary Range**: $70,000 - $150,000+ depending on experience\n" +
                   "📚 **Learning Path**: Statistics → Python/R → SQL → Machine Learning → Portfolio Projects\n\n" +
                   "The field offers excellent growth prospects and is applicable across all industries!";
        }

        return "I'm here to help with your career journey! I can provide guidance on:\n\n" +
               "🎯 Career exploration and recommendations\n" +
               "📈 Skill development and learning paths\n" +
               "💼 Job search strategies and interview tips\n" +
               "💰 Salary insights and negotiation\n" +
               "🎓 Education and certification planning\n" +
               "🚀 Career advancement strategies\n\n" +
               "What specific area would you like to explore? Feel free to ask me anything about your professional development!";
    }
}
