package com.app.service;

import com.app.model.*;
import com.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;

@Service
public class DataInitializationService implements CommandLineRunner {

    @Autowired
    private CareerPathRepository careerPathRepository;

    @Override
    public void run(String... args) throws Exception {
        if (careerPathRepository.count() == 0) {
            initializeCareerData();
        }
    }

    private void initializeCareerData() {
        List<CareerPath> careers = Arrays.asList(
            createCareerPath("Software Developer", "Technology",
                "Design, develop, and maintain software applications and systems",
                "Bachelor's Degree", 70000, 120000, "EXCELLENT",
                Arrays.asList("Programming", "Problem Solving", "Java", "Python", "JavaScript"),
                Arrays.asList("Cloud Computing", "DevOps", "Machine Learning")),

            createCareerPath("Data Scientist", "Technology",
                "Analyze complex data to help organizations make informed decisions",
                "Bachelor's Degree", 80000, 140000, "EXCELLENT",
                Arrays.asList("Statistics", "Python", "Machine Learning", "SQL", "Data Analysis"),
                Arrays.asList("Deep Learning", "Big Data", "Cloud Platforms")),

            createCareerPath("Registered Nurse", "Healthcare",
                "Provide patient care and support in healthcare settings",
                "Associate Degree", 60000, 90000, "GOOD",
                Arrays.asList("Patient Care", "Communication", "Medical Knowledge", "Empathy"),
                Arrays.asList("Specialized Certifications", "Advanced Practice")),

            createCareerPath("Digital Marketing Manager", "Marketing",
                "Develop and execute digital marketing strategies and campaigns",
                "Bachelor's Degree", 55000, 95000, "GOOD",
                Arrays.asList("Digital Marketing", "Analytics", "Social Media", "Content Creation"),
                Arrays.asList("SEO/SEM", "Marketing Automation", "Data Analytics")),

            createCareerPath("UX/UI Designer", "Design",
                "Design user-friendly interfaces and experiences for digital products",
                "Bachelor's Degree", 65000, 110000, "EXCELLENT",
                Arrays.asList("Design", "User Research", "Prototyping", "Creative Thinking"),
                Arrays.asList("Advanced Design Tools", "Motion Graphics", "Design Systems")),

            createCareerPath("Financial Analyst", "Finance",
                "Analyze financial data and provide investment recommendations",
                "Bachelor's Degree", 60000, 100000, "GOOD",
                Arrays.asList("Financial Analysis", "Excel", "Modeling", "Communication"),
                Arrays.asList("CFA Certification", "Advanced Analytics", "Risk Management")),

            createCareerPath("Cybersecurity Specialist", "Technology",
                "Protect organizations from cyber threats and security breaches",
                "Bachelor's Degree", 75000, 130000, "EXCELLENT",
                Arrays.asList("Network Security", "Risk Assessment", "Security Tools", "Problem Solving"),
                Arrays.asList("Ethical Hacking", "Cloud Security", "Compliance")),

            createCareerPath("Project Manager", "Business",
                "Plan, execute, and oversee projects from initiation to completion",
                "Bachelor's Degree", 70000, 115000, "GOOD",
                Arrays.asList("Project Management", "Leadership", "Communication", "Organization"),
                Arrays.asList("PMP Certification", "Agile Methodologies", "Risk Management")),

            createCareerPath("Data Engineer", "Technology",
                "Build and maintain data infrastructure and pipelines",
                "Bachelor's Degree", 85000, 135000, "EXCELLENT",
                Arrays.asList("Database Management", "ETL", "Programming", "Data Architecture"),
                Arrays.asList("Big Data Technologies", "Cloud Platforms", "Real-time Processing")),

            createCareerPath("Environmental Engineer", "Engineering",
                "Develop solutions to environmental problems and sustainability challenges",
                "Bachelor's Degree", 65000, 105000, "GOOD",
                Arrays.asList("Environmental Science", "Engineering", "Problem Solving", "Research"),
                Arrays.asList("Renewable Energy", "Environmental Consulting", "Sustainability"))
        );

        careerPathRepository.saveAll(careers);
        System.out.println("✅ Initialized " + careers.size() + " career paths");
    }

    private CareerPath createCareerPath(String title, String industry, String description,
                                      String education, int salaryMin, int salaryMax, String outlook,
                                      List<String> requiredSkills, List<String> preferredSkills) {
        CareerPath career = new CareerPath(title, industry);
        career.setDescription(description);
        career.setEducationRequired(education);
        career.setAverageSalaryMin(salaryMin);
        career.setAverageSalaryMax(salaryMax);
        career.setJobOutlook(outlook);
        career.setRequiredSkills(requiredSkills);
        career.setPreferredSkills(preferredSkills);
        career.setWorkEnvironment("HYBRID");
        return career;
    }
}
