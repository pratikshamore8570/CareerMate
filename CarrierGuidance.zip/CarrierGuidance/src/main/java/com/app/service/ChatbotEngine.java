package com.app.service;

import com.app.dto.*;
import com.app.model.*;
import com.app.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ChatbotEngine {

    @Autowired
    private GeminiService geminiService;

    @Autowired(required = false)
    private CareerRecommendationService careerService;

    @Autowired(required = false)
    private NLPService nlpService;

    @Autowired(required = false)
    private TranslationService translationService;

    public ChatResponse processMessage(ChatRequest request, User user) {
        ChatResponse response = new ChatResponse();

        try {
            // Use Gemini API for intelligent career guidance responses
            String aiResponse = geminiService.getCareerGuidanceResponse(request.getMessage());

            response.setMessage(aiResponse);
            response.setConfidenceScore(0.95f);
            response.setSessionId(request.getSessionId() != null ? request.getSessionId().toString() : null);

            // Add some follow-up questions based on the message content
            response.setFollowUpQuestions(generateSmartFollowUpQuestions(request.getMessage()));

        } catch (Exception e) {
            // Fallback to a helpful default response
            response.setMessage("I'm here to help with your career questions! You can ask me about career paths, skills, job search tips, salary information, or anything related to professional development. What would you like to explore today?");
            response.setConfidenceScore(1.0f);
        }

        return response;
    }

    private List<String> generateSmartFollowUpQuestions(String userMessage) {
        List<String> questions = new ArrayList<>();
        String lowerMessage = userMessage.toLowerCase();

        if (lowerMessage.contains("career") || lowerMessage.contains("job")) {
            questions.add("What industries interest you most?");
            questions.add("What's your educational background?");
            questions.add("Are you looking for remote work opportunities?");
        } else if (lowerMessage.contains("skill")) {
            questions.add("What's your current experience level?");
            questions.add("Do you prefer self-paced or structured learning?");
            questions.add("Are you interested in obtaining certifications?");
        } else if (lowerMessage.contains("salary")) {
            questions.add("What's your target location for work?");
            questions.add("Are you open to negotiating other benefits?");
            questions.add("Would you like tips on salary negotiation?");
        } else {
            questions.add("What specific career area interests you?");
            questions.add("What are your main career goals?");
            questions.add("How can I best assist your career development?");
        }

        return questions;
    }
}