package com.app.service;

import com.app.dto.*;
import com.app.model.*;
import com.app.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CareerRecommendationService {

    @Autowired
    private CareerPathRepository careerPathRepository;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private UserRepository userRepository;

    // Enhanced AI/ML matching algorithm for career recommendations
    public List<CareerRecommendation> getCareerRecommendations(User user, List<String> interests) {
        UserProfile profile = user.getProfile();
        if (profile == null) {
            return getDefaultRecommendations();
        }

        List<CareerPath> allCareers = careerPathRepository.findAll();
        if (allCareers.isEmpty()) {
            return getDefaultRecommendations();
        }

        List<String> userInterests = interests != null ? interests :
            (profile.getInterests() != null ? profile.getInterests() : new ArrayList<>());

        return allCareers.stream()
            .map(career -> calculateEnhancedMatch(career, profile, userInterests))
            .filter(rec -> rec.getMatchScore() > 0.2f) // Lowered threshold for more results
            .sorted((a, b) -> Float.compare(b.getMatchScore(), a.getMatchScore()))
            .limit(8) // Increased limit
            .collect(Collectors.toList());
    }

    private CareerRecommendation calculateEnhancedMatch(CareerPath career, UserProfile profile, List<String> interests) {
        float matchScore = 0.0f;
        StringBuilder reasoning = new StringBuilder();
        List<String> matchFactors = new ArrayList<>();

        // Interest matching (30% weight)
        float interestScore = calculateInterestMatch(career, profile, interests);
        matchScore += interestScore * 0.30f;
        if (interestScore > 0.4f) {
            matchFactors.add("Strong interest alignment");
        }

        // Skill matching (25% weight)
        float skillScore = calculateSkillMatch(career, profile);
        matchScore += skillScore * 0.25f;
        if (skillScore > 0.3f) {
            matchFactors.add("Good skill match");
        }

        // Industry preference (15% weight)
        float industryScore = calculateIndustryMatch(career, profile);
        matchScore += industryScore * 0.15f;
        if (industryScore > 0.8f) {
            matchFactors.add("Preferred industry");
        }

        // Education matching (10% weight)
        float educationScore = calculateEducationMatch(career, profile);
        matchScore += educationScore * 0.10f;
        if (educationScore > 0.8f) {
            matchFactors.add("Education requirements met");
        }

        // Salary expectations (10% weight)
        float salaryScore = calculateSalaryMatch(career, profile);
        matchScore += salaryScore * 0.10f;
        if (salaryScore > 0.8f) {
            matchFactors.add("Salary expectations aligned");
        }

        // Career stage matching (5% weight)
        float careerStageScore = calculateCareerStageMatch(career, profile);
        matchScore += careerStageScore * 0.05f;
        if (careerStageScore > 0.8f) {
            matchFactors.add("Appropriate career level");
        }

        // Work environment preference (5% weight)
        float workEnvScore = calculateWorkEnvironmentMatch(career, profile);
        matchScore += workEnvScore * 0.05f;
        if (workEnvScore > 0.8f) {
            matchFactors.add("Preferred work environment");
        }

        reasoning.append(String.join(", ", matchFactors));
        if (reasoning.length() == 0) {
            reasoning.append("Basic compatibility match");
        }

        CareerRecommendation recommendation = new CareerRecommendation(
            career.getTitle(),
            career.getIndustry(),
            Math.min(matchScore * 100, 100.0f) // Convert to percentage
        );
        recommendation.setDescription(career.getDescription());
        recommendation.setSalaryRange((career.getAverageSalaryMin() + career.getAverageSalaryMax()) / 2);
        recommendation.setReasoning(reasoning.toString());
        recommendation.setRequiredSkills(career.getRequiredSkills());
        recommendation.setGrowthPotential(career.getJobOutlook());

        return recommendation;
    }

    private float calculateInterestMatch(CareerPath career, UserProfile profile, List<String> interests) {
        if (profile.getInterests() == null || profile.getInterests().isEmpty()) {
            return 0.3f; // Default score if no interests
        }

        Set<String> careerKeywords = extractCareerKeywords(career);
        long matchingInterests = profile.getInterests().stream()
            .mapToLong(userInterest ->
                careerKeywords.stream().anyMatch(keyword ->
                    keyword.toLowerCase().contains(userInterest.toLowerCase()) ||
                    userInterest.toLowerCase().contains(keyword.toLowerCase())
                ) ? 1 : 0
            ).sum();

        return Math.min((float) matchingInterests / Math.max(profile.getInterests().size(), 1), 1.0f);
    }

    private float calculateSkillMatch(CareerPath career, UserProfile profile) {
        if (profile.getSkills() == null || profile.getSkills().isEmpty()) {
            return 0.2f; // Default score if no skills
        }

        List<String> requiredSkills = career.getRequiredSkills();
        if (requiredSkills == null || requiredSkills.isEmpty()) {
            return 0.5f; // Neutral score if no required skills specified
        }

        long matchingSkills = profile.getSkills().stream()
            .mapToLong(userSkill ->
                requiredSkills.stream().anyMatch(reqSkill ->
                    reqSkill.toLowerCase().contains(userSkill.toLowerCase()) ||
                    userSkill.toLowerCase().contains(reqSkill.toLowerCase())
                ) ? 1 : 0
            ).sum();

        return Math.min((float) matchingSkills / Math.max(requiredSkills.size(), 1), 1.0f);
    }

    private float calculateIndustryMatch(CareerPath career, UserProfile profile) {
        if (profile.getPreferredIndustry() == null) {
            return 0.5f; // Neutral score if no preference
        }

        return profile.getPreferredIndustry().equalsIgnoreCase(career.getIndustry()) ? 1.0f : 0.3f;
    }

    private float calculateEducationMatch(CareerPath career, UserProfile profile) {
        if (profile.getUser() == null || career.getEducationRequired() == null) {
            return 0.5f; // Neutral score if data missing
        }

        return isEducationMatch(profile.getUser().getEducation(), career.getEducationRequired()) ? 1.0f : 0.2f;
    }

    private float calculateSalaryMatch(CareerPath career, UserProfile profile) {
        if (profile.getExpectedSalaryMin() == null) {
            return 0.5f; // Neutral score if no expectation
        }

        int careerAvgSalary = (career.getAverageSalaryMin() + career.getAverageSalaryMax()) / 2;
        if (careerAvgSalary >= profile.getExpectedSalaryMin()) {
            return 1.0f;
        } else if (careerAvgSalary >= profile.getExpectedSalaryMin() * 0.8) {
            return 0.7f; // Close to expectations
        } else {
            return 0.3f; // Below expectations
        }
    }

    private float calculateCareerStageMatch(CareerPath career, UserProfile profile) {
        if (profile.getCareerStage() == null) {
            return 0.5f; // Neutral score if no stage specified
        }

        // This would need career stage data in CareerPath model
        // For now, return neutral score
        return 0.5f;
    }

    private float calculateWorkEnvironmentMatch(CareerPath career, UserProfile profile) {
        if (profile.getWorkEnvironment() == null) {
            return 0.5f; // Neutral score if no preference
        }

        // This would need work environment data in CareerPath model
        // For now, return neutral score
        return 0.5f;
    }

    private Set<String> extractCareerKeywords(CareerPath career) {
        Set<String> keywords = new HashSet<>();

        // Extract keywords from title and description
        if (career.getTitle() != null) {
            keywords.addAll(Arrays.asList(career.getTitle().toLowerCase().split("\\s+")));
        }
        if (career.getDescription() != null) {
            keywords.addAll(Arrays.asList(career.getDescription().toLowerCase().split("\\s+")));
        }
        if (career.getIndustry() != null) {
            keywords.add(career.getIndustry().toLowerCase());
        }

        return keywords;
    }

    public List<CareerRecommendation> getDefaultRecommendations() {
        // Provide some default recommendations when profile is incomplete
        List<CareerRecommendation> defaults = new ArrayList<>();

        defaults.add(new CareerRecommendation("Software Developer", "Technology", 75.0f));
        defaults.add(new CareerRecommendation("Data Analyst", "Technology", 70.0f));
        defaults.add(new CareerRecommendation("Project Manager", "Business", 65.0f));
        defaults.add(new CareerRecommendation("Marketing Specialist", "Marketing", 60.0f));

        for (CareerRecommendation rec : defaults) {
            rec.setDescription("Complete your profile for personalized recommendations");
            rec.setReasoning("Based on popular career paths");
            rec.setSalaryRange(60000);
            rec.setGrowthPotential("GOOD");
            rec.setRequiredSkills(Arrays.asList("Communication", "Problem Solving", "Teamwork"));
        }

        return defaults;
    }

    public Map<String, Integer> assessSkills(List<String> skills, User user) {
        Map<String, Integer> assessment = new HashMap<>();

        // Enhanced skill assessment based on user profile
        for (String skill : skills) {
            int score = calculateSkillScore(skill, user);
            assessment.put(skill, score);
        }

        return assessment;
    }

    public Map<String, Object> getSalaryInformation(String jobTitle, String location) {
        // This would integrate with salary APIs like Glassdoor, PayScale, etc.
        Map<String, Object> salaryInfo = new HashMap<>();

        // Simulate salary data based on job title and location
        int baseMin = 50000;
        int baseMax = 80000;

        // Adjust based on job title
        if (jobTitle.toLowerCase().contains("senior") || jobTitle.toLowerCase().contains("lead")) {
            baseMin += 30000;
            baseMax += 50000;
        } else if (jobTitle.toLowerCase().contains("manager") || jobTitle.toLowerCase().contains("director")) {
            baseMin += 40000;
            baseMax += 70000;
        }

        // Adjust based on location (simplified)
        if (location.toLowerCase().contains("san francisco") || location.toLowerCase().contains("new york")) {
            baseMin = (int)(baseMin * 1.3);
            baseMax = (int)(baseMax * 1.3);
        }

        salaryInfo.put("min", baseMin + (int)(Math.random() * 10000));
        salaryInfo.put("max", baseMax + (int)(Math.random() * 20000));
        salaryInfo.put("median", (baseMin + baseMax) / 2 + (int)(Math.random() * 15000));
        salaryInfo.put("currency", "USD");
        salaryInfo.put("source", "Industry Data");

        return salaryInfo;
    }

    public List<CareerPath> getCareerProgressionPath(String currentRole, String targetRole) {
        // ML-based career progression mapping
        List<CareerPath> progressionPath = new ArrayList<>();

        // This would use graph algorithms to find optimal career paths
        // For now, return a simulated progression based on career paths in database
        List<CareerPath> allCareers = careerPathRepository.findAll();

        // Simple progression logic - find intermediate roles
        allCareers.stream()
            .filter(career -> career.getTitle().toLowerCase().contains("senior") ||
                             career.getTitle().toLowerCase().contains("lead"))
            .limit(3)
            .forEach(progressionPath::add);

        return progressionPath;
    }

    // Enhanced profile-based recommendation for specific user
    public List<CareerRecommendation> getPersonalizedRecommendations(Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) {
            return getDefaultRecommendations();
        }

        User user = userOpt.get();
        UserProfile profile = user.getProfile();

        if (profile == null) {
            return getDefaultRecommendations();
        }

        return getCareerRecommendations(user, profile.getInterests());
    }

    private boolean isEducationMatch(String userEducation, String requiredEducation) {
        if (userEducation == null || requiredEducation == null) return false;

        Map<String, Integer> educationLevels = Map.of(
            "HIGH_SCHOOL", 1,
            "ASSOCIATE", 2,
            "BACHELOR", 3,
            "MASTER", 4,
            "DOCTORATE", 5
        );

        return educationLevels.getOrDefault(userEducation.toUpperCase(), 0) >=
               educationLevels.getOrDefault(requiredEducation.toUpperCase(), 0);
    }

    private int calculateSkillScore(String skill, User user) {
        // Enhanced skill scoring based on user profile
        UserProfile profile = user.getProfile();

        if (profile != null && profile.getSkills() != null) {
            boolean hasSkill = profile.getSkills().stream()
                .anyMatch(userSkill -> userSkill.toLowerCase().contains(skill.toLowerCase()) ||
                                     skill.toLowerCase().contains(userSkill.toLowerCase()));

            if (hasSkill) {
                return 7 + new Random().nextInt(3); // Score 7-9 for known skills
            }
        }

        // Base score for unknown skills
        return 3 + new Random().nextInt(4); // Score 3-6 for unknown skills
    }
}


