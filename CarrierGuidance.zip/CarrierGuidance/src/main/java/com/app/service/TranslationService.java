package com.app.service;

import com.app.dto.*;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class TranslationService {

    private final Map<String, String> supportedLanguages = initializeSupportedLanguages();

    public ChatResponse translateResponse(ChatResponse response, String targetLanguage) {
        if (!supportedLanguages.containsKey(targetLanguage) || targetLanguage.equals("en")) {
            return response;
        }

        try {
            String translatedMessage = translateText(response.getMessage(), "en", targetLanguage);
            response.setMessage(translatedMessage);
            response.setLanguage(targetLanguage);

            // Translate follow-up questions
            if (response.getFollowUpQuestions() != null) {
                List<String> translatedQuestions = new ArrayList<>();
                for (String question : response.getFollowUpQuestions()) {
                    translatedQuestions.add(translateText(question, "en", targetLanguage));
                }
                response.setFollowUpQuestions(translatedQuestions);
            }

        } catch (Exception e) {
            // Fallback to original language if translation fails
            response.setLanguage("en");
        }

        return response;
    }

    public String translateText(String text, String sourceLanguage, String targetLanguage) {
        if (text == null || text.trim().isEmpty()) {
            return text;
        }

        // Simple mock translation for now - in production would use Google Translate API
        return text; // Return original text for now
    }

    public String detectLanguage(String text) {
        // Simple language detection based on common patterns
        if (text.matches(".*[àáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ].*")) {
            return "es"; // Spanish/Romance languages
        } else if (text.matches(".*[äöüß].*")) {
            return "de"; // German
        } else if (text.matches(".*[àâäçéèêëïîôöùûüÿ].*")) {
            return "fr"; // French
        }
        return "en"; // Default to English
    }

    public List<String> getSupportedLanguagesList() {
        return new ArrayList<>(supportedLanguages.keySet());
    }

    public String getLanguageName(String code) {
        return supportedLanguages.getOrDefault(code, "English");
    }

    private Map<String, String> initializeSupportedLanguages() {
        Map<String, String> languages = new HashMap<>();
        languages.put("en", "English");
        languages.put("es", "Spanish");
        languages.put("fr", "French");
        languages.put("de", "German");
        languages.put("it", "Italian");
        languages.put("pt", "Portuguese");
        languages.put("zh", "Chinese");
        languages.put("ja", "Japanese");
        languages.put("ko", "Korean");
        languages.put("hi", "Hindi");
        languages.put("ar", "Arabic");
        languages.put("ru", "Russian");
        return languages;
    }
}

