package com.app;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class CarrierGuidanceApplication
{
    public static void main( String[] args )
    {
        SpringApplication.run(CarrierGuidanceApplication.class, args);
        System.out.println( "🚀 Career Guidance Chatbot System Started Successfully!" );
        System.out.println( "📊 Features: AI-powered career advice, multi-language support, voice interaction" );
        System.out.println( "🌐 Access the API at: http://localhost:8080" );
    }
}
